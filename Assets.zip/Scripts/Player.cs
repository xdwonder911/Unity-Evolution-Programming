﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    System.Random rnd;
    string ThrustLOG="";
    public float rotationSpeed=2f;
    public GameObject Explosion;
    GameObject Instantiated_expl;

    Rigidbody rb;
    public int generation;


    public int nthInGen = 0;
    static public int nthInGenCounter = 0;
   // public int id;
    //static public int idcounter=0;

    public float timer;
    public int timeAlive = 0;

    public float[] dna;
    public int succesfullThrusts = 0;
    /// <summary>
    /// I dunno man
    /// </summary>
    public int FinalsucessfulThrust = 0;


   
    public int thrusterIndex=0;

    public bool crashed = false;
    public bool crashedOnTop = false;


	// Use this for initialization
	void Start () {
       // id = idcounter++;
        rb = GetComponent<Rigidbody>();
        rnd = new System.Random();
        generation = GM.currentGen;

        nthInGen = nthInGenCounter;
        nthInGenCounter++;

        if (generation == 0)
            GenerateDNAforFirstGEN();
        else
        {
           /* string xxxx = "";
            for(int i=0;i<15;i++)
            {
                xxxx += i+". child DNA = ";
                float[] arr = GM.newDNAsList[i];
                for (int j = 0; j < 20; j++)   
                    xxxx += arr[j]+",";
                xxxx += "\n";
                
            }
            Debug.Log(xxxx);


            string xx = "Creating "+ nthInGen+". Child with DNA= ";
            float[] xy;
            for (int i = 0; i < 20; i++)
            {
                xy = GM.newDNAsList[nthInGen];
                xx += xy[i] + ", ";
            }

            Debug.Log(xx);
            */

            dna = GM.newDNAsList[nthInGen];  



        }
        GameObject.Find("STAGE").GetComponent<Stage>().Reset();
        StartCoroutine(Thrust());
    }

    void Update()
    {
        this.transform.Rotate(Vector3.up*Time.deltaTime*rotationSpeed,Space.World);
        //timeAlive++; FUCK IT LET'S DO IT HIGH
    }


	/*public void Play()
    {

        if (dna == null)
            GenerateDNAforFirstGEN();
      
        // StartCoroutine(Thrust());
    }*/

    IEnumerator Thrust()
    {

        succesfullThrusts++;
        this.GetComponent<AudioSource>().Play();
        ThrustLOG += succesfullThrusts+". "+dna[thrusterIndex]+"      ";
           // rb.AddForce(new Vector3(0, dna[thrusterIndex], 0));
        rb.velocity = new Vector3(0, dna[thrusterIndex], 0);
        thrusterIndex++;
            yield return new WaitForSeconds(0.5f);
        if (!crashed)
            if (thrusterIndex < 10000)
                StartCoroutine(Thrust());
            else yield return null;
      /*  if (!crashed)
        { }
       */
        }

    public void OnCollisionEnter(Collision other)
    {
        if (!crashed)
          { 
            Debug.Log("ThrustLOG:" + ThrustLOG);

                 if (other.gameObject.name == "top")
              {
                 crashedOnTop = true;
                 }
    



           Die();
          }
    }


 
    void GenerateDNAforFirstGEN()//only for the first population
    {
        dna = new float[100000];
        timer = 0;

        for (int i = 0; i < 100000; i++)
        {
            float tmp = rnd.Next(0, 4000);
            tmp = tmp / 1000;
            dna[i] = tmp;// rnd.Next(0, 1000) / 1000;
                         // Debug.Log("Random Thruster= "+ tmp);
        }

    }


    void Die()
    {
        Instantiated_expl=Instantiate(Explosion,this.transform.position,Quaternion.identity);        
        //Instantiated_expl.GetComponent<ParticleSystem>().Emit(1);
        //Instantiated_expl.transform.GetChild(0).GetComponent<ParticleSystem>().Emit(1);
       // Instantiated_expl.transform.GetChild(1).GetComponent<ParticleSystem>().Emit(1);
       // Instantiated_expl.transform.GetChild(2).GetComponent<ParticleSystem>().Emit(1);
       // Instantiated_expl.transform.GetChild(3).GetComponent<ParticleSystem>().Emit(1);
        Instantiated_expl.GetComponent<AudioSource>().Play();
        Invoke("RemoveExplosion", 3f);
       

        this.gameObject.SetActive(false);
        crashed = true;
        FinalsucessfulThrust = succesfullThrusts;
        timeAlive = FinalsucessfulThrust;
       // Debug.Log("Time Alive = " + timeAlive);
        /*this.GetComponent<MeshRenderer>().enabled = false;
        Destroy(this.GetComponent<CapsuleCollider>());//.enabled = false;
        Destroy(this.GetComponent<Rigidbody>());
        
        this.transform.GetChild(0).gameObject.GetComponent<MeshRenderer>().enabled = false;
        this.transform.GetChild(1).gameObject.GetComponent<MeshRenderer>().enabled = false;*/
    }

    void RemoveExplosion()
    {
        Destroy(Instantiated_expl);
    }

}

