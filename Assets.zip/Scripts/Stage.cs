﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage : MonoBehaviour {

    // Use this for initialization
  //  Transform myTransform;

	void Start () {
    //    myTransform = this.transform;

    }
	
	// Update is called once per frame
	void Update () {

        this.transform.position= new Vector3(this.transform.position.x-0.003f, this.transform.position.y, this.transform.position.z);
	}

     public void Reset()
    {
        this.transform.position = new Vector3(4.02914f, 0.6171477f, -1.716797f);
    }
}
