﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GM : MonoBehaviour {


    public static int currentGen = 0;
    public int MutationChance = 25;

    public Text GenerationTEXT;
    public Text FitnesTEXT;
    int BestTimeAlive = 0;
    int AlltimeBestTimeAlive = 0;

    public int PopulationSize = 5;
    public int GenerationSize = 5;
    public int NumberOfRockets = 0;

    List<GameObject> rocketlist = new List<GameObject>();
    GameObject currentSpecimen;
    public GameObject specimen;

    float[] childDNA;// = new float[100000];
    System.Random rnd;// = new System.Random();
    System.Random rndx = new System.Random();


    public static List<float[]> newDNAsList = new List<float[]>();




    string rndDebug = "RANDOM PICKS:";

	// Use this for initialization
	void Start () {
        Physics.gravity = new Vector3(0, -3F, 0);
        rnd = new System.Random();
        Evolution();
    }
	// Update is called once per frame
	void Update () {
        UpdateText();
      /*  if(Input.GetKeyDown(KeyCode.Space))
        {
            GameObject.Find("RocketBOI").GetComponent<Rigidbody>().AddForce(new Vector3(0, 400f, 0));
        }*/

    }

    void StartTest()
    {
       currentSpecimen = Instantiate(specimen, specimen.transform.position, Quaternion.identity);
        rocketlist.Add(currentSpecimen);
        NumberOfRockets++;
        StartCoroutine(Respawner());
    }


IEnumerator Respawner()
{
        if (currentSpecimen.GetComponent<Player>().crashed)
        {
            if (NumberOfRockets < PopulationSize)
            {
                currentSpecimen = Instantiate(specimen, specimen.transform.position, Quaternion.identity);
                rocketlist.Add(currentSpecimen);
                NumberOfRockets++;
            }
            else
            {
                SortByScore();
                
                //newDNAsList.Add(rocketlist[PopulationSize-1].GetComponent<Player>().dna);
                //newDNAsList.Add(rocketlist[PopulationSize - 2].GetComponent<Player>().dna);

                


                string tmps="";
                for (int i = 0; i < PopulationSize; i++)
                    tmps += (rocketlist[i].GetComponent<Player>().succesfullThrusts+", ");
                Debug.Log(tmps);
                /*

                //   Debug.Log("AddingRocketsBackToPool_Scores1/2:"+ rocketlist[0].GetComponent<Player>().timeAlive+"___"+ rocketlist[1].GetComponent<Player>().timeAlive);
                //    Debug.Log("3/4::::" + rocketlist[2].GetComponent<Player>().timeAlive + "___" + rocketlist[3].GetComponent<Player>().timeAlive);

                int ix = 0;
                for (int i=1;i<PopulationSize-2;i++)//i=2 skips adding worst first 2
                {
                    newDNAsList.Add(rocketlist[i].GetComponent<Player>().dna);
                }*/

               // GameObject[] BestParents = new GameObject[2];
               // BestParents[0] = rocketlist[PopulationSize - 1];
               // BestParents[1] = rocketlist[PopulationSize-2];
                Debug.Log("Picked fitnesses "+ rocketlist[PopulationSize - 2].GetComponent<Player>().succesfullThrusts+"," +rocketlist[PopulationSize - 1].GetComponent<Player>().succesfullThrusts);

                GameObject[] BestParents1 = GetBestParents();
                
                newDNAsList.Clear();
                float [] tmpArray=new float[100000];
                string tmpS="";
                for (int i = 0; i < PopulationSize; i++)
                {
                    float[] tmp = new float[2];
                     tmp=CreateChild(BestParents1);//BestParents
                    newDNAsList.Add(tmp);
                    tmpArray = newDNAsList[i];
                    for (int j = 0; j < 20; j++)
                    {
                        tmpS += tmpArray[j] + ", ";
                    }
                    Debug.Log("New "+i+". Chidl DNA is "+tmpS);
                    tmpS = "";
                }

                /* //WTF MAN
                 for (int i = 0; i < PopulationSize; i++)
                 {

                     tmpArray = newDNAsList[i];
                     for (int j = 0; j < 20; j++)
                     {
                         tmpS += tmpArray[j] + ",";
                     }
                     Debug.Log("New " + i + ". Chidl DNA is " + tmpS);
                     tmpS = "";
                 }

                 */








                Mutate();

                for (int i = 0; i < PopulationSize; i++)
                {

                    tmpArray = newDNAsList[i];
                    for (int j = 0; j < 20; j++)
                    {
                        tmpS += tmpArray[j] + ", ";
                    }
                    Debug.Log("New " + i + ". Chidl DNA is " + tmpS);
                    tmpS = "";
                }


                Debug.Log(rndDebug);

                currentGen++;
                BestTimeAlive = 0;
                NumberOfRockets = 0;
                Player.nthInGenCounter = 0;
                rocketlist.Clear();
                StartTest();
                yield return null;
            }
        }
        yield return new WaitForSeconds(0.1f);
        StartCoroutine(Respawner());
    }




void Evolution()
    {
        StartTest();
        
    }

    void Mutate()
    {
        ImproveAllDNA();


    }
    void SortByScore()
    {
        rocketlist.Sort((rocket1,rocket2)=>rocket1.GetComponent<Player>().timeAlive.CompareTo(rocket2.GetComponent<Player>().timeAlive));
    }

    GameObject[] GetBestParents()
    {
        
      
        GameObject[] pair = new GameObject[2];
       /*
        float rndF;
 
        for (int i = 0; i < 2; i++)
        {            
            rndF = ((float)(rndx.Next(0, 1000))/1000);

            int index = (int)(Mathf.Pow(rndF, 0.5f) * (PopulationSize - 1));/////////NAJDU DSA SA D
            rndDebug += index + ", ";
            pair[i]= rocketlist[index];        
        }
        */

        pair[0] = rocketlist[PopulationSize - 1];
        pair[1] = rocketlist[PopulationSize - 2];

        return pair;
    }

    float[] CreateChild(GameObject [] pair)// mutation INSIDE
    {
     childDNA = new float[100000];
        Debug.Log("Copying "+ (pair[0].GetComponent<Player>().succesfullThrusts - 1)+ " parent DNA cells  ");
        for (int i=0;i< pair[0].GetComponent<Player>().succesfullThrusts-1;i++)
        {

            //UP NEED TO BE CHANGED IF WE WANT RANDOM; THIS WILL DO FOR NOW DOWN

            //childDNA[i] = pair[0].GetComponent<Player>().dna[i];
            switch (rnd.Next(0, 1))//0
            {
                case 0:
                    childDNA[i] = pair[0].GetComponent<Player>().dna[i];
                    break;
                case 1:
                    childDNA[i] = pair[1].GetComponent<Player>().dna[i];
                    break;
            }
        }

        //timeAlive-
        for(int i= pair[0].GetComponent<Player>().succesfullThrusts-1;i< 100000;i++)//-2 -> nočemo 2 zadnih thrustov preden je crashu v zid-> NAZADNJE -1
       // for (int i=0;i<100000;i++)
        {
            //  Debug.Log("ASD;;" + pair[0].GetComponent<Player>().FinalsucessfulThrust);
            /*switch (rnd.Next(0, 1))
            { case 0:
                    childDNA[i] = pair[0].GetComponent<Player>().dna[i];
                    break;
                case 1:
                    childDNA[i] = pair[1].GetComponent<Player>().dna[i];
                    break;
            }*/

            //KINDA WORKING DOWNSTAIRS
            /*
            if (rnd.Next(0, 100) < 80)         
                childDNA[i] = pair[0].GetComponent<Player>().dna[i];   
            else
                childDNA[i] = pair[1].GetComponent<Player>().dna[i];

            if (rnd.Next(0, 100) < MutationChance)
            {
                float tmp = rnd.Next(0, 1000);
                tmp = tmp / 2.5f;
                childDNA[i] = tmp;
            }*/
            float tmp = rnd.Next(0, 4000);
            tmp = tmp / 1000;
            childDNA[i] = tmp;


        }
        return childDNA;
    }

    void ImproveAllDNA()
    {
        float[] DNA=new float[10000];
        int mutatedDNAindex;
        for(int i= 0;i< newDNAsList.Count;i++)
       {
            float tmp;
            
            DNA = newDNAsList[i];
            mutatedDNAindex = rocketlist[PopulationSize - 1].GetComponent<Player>().FinalsucessfulThrust;//SAME
            mutatedDNAindex -= 2;//zato ker štetje sucesfulthrustov začnem z 1 pa še index tabele 
            if (rocketlist[PopulationSize - 1].GetComponent<Player>().crashedOnTop == true)//GOOD UPGREJ SAM NE DANS , ko bom naredu random fotre usaj maj, da uzema od njegouga- zaenkrat je vedno prvi najbolsi foter
            {
                tmp = rnd.Next(0, 2500);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex - 5] = tmp;

                tmp = rnd.Next(0, 2000);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex - 4] = tmp;

                tmp = rnd.Next(0, 1000);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex - 3] = tmp;

                tmp = rnd.Next(0, 1000);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex-2] = tmp;

                tmp = rnd.Next(0, 700);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex-1] = tmp;

                tmp = rnd.Next(0, 100);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex] = tmp;

                tmp = rnd.Next(0, 100);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex+1] = tmp;

                tmp = rnd.Next(0, 100);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex+2] = tmp;
                Debug.Log(rocketlist[PopulationSize - 1].GetComponent<Player>().nthInGen + "Improved By Lowering dna to " + tmp + " on Child" + i + " on Index" + mutatedDNAindex);
            }
            else {
                tmp = rnd.Next(3000, 4000);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex-2] = tmp;

                tmp = rnd.Next(3700, 4000);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex-1] = tmp;

                tmp = rnd.Next(3900, 4000);
                tmp = tmp / 1000;
                DNA[mutatedDNAindex] = tmp;
                Debug.Log(rocketlist[PopulationSize - 1].GetComponent<Player>().nthInGen + "Improved By Increasing dna to " + tmp + " on Child" + i+" on Index"+mutatedDNAindex);
            }



            if (rocketlist[PopulationSize - 1].GetComponent<Player>().crashedOnTop == true)//GOOD UPGREJ SAM NE DANS , ko bom naredu random fotre usaj maj, da uzema od njegouga- zaenkrat je vedno prvi najbolsi foter
            {

                tmp = rnd.Next(0, 2000);
                tmp = tmp / 1000;//1000
                DNA[mutatedDNAindex-1] = tmp;             
            }
            else {
                tmp = rnd.Next(2000, 4000);
                tmp = tmp / 1000;//1000
                DNA[mutatedDNAindex-1] = tmp;             
            }

            //   Debug.Log("CrashedOnTop=" + rocketlist[0].GetComponent<Player>().crashedOnTop);

            newDNAsList[i] = DNA;
        }

      /*  for (int i = 0; i < newDNAsList.Count; i++)
        {


        }*/




    }

    void UpdateText()
    {
        GenerationTEXT.text = "GENERATION: " + currentSpecimen.GetComponent<Player>().generation + "\nSPECIMEN: " + currentSpecimen.GetComponent<Player>().nthInGen;


        if (currentSpecimen.GetComponent<Player>().succesfullThrusts > BestTimeAlive)
        {
            BestTimeAlive = currentSpecimen.GetComponent<Player>().succesfullThrusts;

            if (currentSpecimen.GetComponent<Player>().succesfullThrusts > AlltimeBestTimeAlive)
                AlltimeBestTimeAlive = currentSpecimen.GetComponent<Player>().succesfullThrusts;

        }
        

        FitnesTEXT.text = "FITNESS: " + currentSpecimen.GetComponent<Player>().succesfullThrusts+"\nCURRENT MAX FITNESS: " + BestTimeAlive+ "\nALLTIME MAX FITNESS: " + AlltimeBestTimeAlive;

    }
}
